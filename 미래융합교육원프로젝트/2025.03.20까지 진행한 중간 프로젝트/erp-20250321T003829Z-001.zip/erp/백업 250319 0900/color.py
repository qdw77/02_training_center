class Color:
    GRAY = "#E3E3E3" # 도구모음 배경panel
    BLACK = "#000000" # 폰트 색상
    WHITE = "#FFFFFF" # 바탕 색상
    BUTTON = "#5ED4FF" # 로고 로그인버튼 시각화
    FOCUS = "#9DB4CF" # 활성화 focus상태
    VISUALIZE1 = "#A9C5D2" # 시각화
    VISUALIZE2 = "#C79797" # 시각화