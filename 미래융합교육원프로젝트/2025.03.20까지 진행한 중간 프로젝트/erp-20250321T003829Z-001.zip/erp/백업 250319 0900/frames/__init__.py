
__all__ = [
    "dashboard", "sample", "sample2", "test_apprreq", "test_apprpaper", "chat_frame",
    "attendance_status", "company_information", "employee_management", "overtime_management", "Time_off_management", "serverance_pay", "pay_stub",
    "materialFrame", "SOP", "BOM", "MO", "Plant", "shipping", "plantFrame", "PO", "receiving",
    "order_form", "Sales_Performance", "add_business_partner",
    "Production_cost_analysis_1", "Production_cost_analysis_2", "income_statement", "Financial_statement", "ac_accountbook", "ac_accountsubject", "ac_taxinvoice",

]
